// ✅ /components/StockLogo.js — Shared logo component (used by Favorites, MarketSection, ScannerSection)
// Fallback chain: Parqet (ticker-based, built for stocks) → unavatar.io (domain-based) → styled initials badge.
// Any image that loads but is too low-resolution to look sharp at our display
// size is treated as a failure too, so we never show a blurry/pixelated icon.
import { useState } from "react";

const MIN_ACCEPTABLE_PX = 48; // reject favicons smaller than this (they'll look blurry when scaled up)

// Deterministic color per symbol so the initials fallback looks intentional
// and varied, instead of a flat gray/white circle.
function colorFromSymbol(symbol) {
  let hash = 0;
  for (let i = 0; i < symbol.length; i++) hash = symbol.charCodeAt(i) + ((hash << 5) - hash);
  const hue = Math.abs(hash) % 360;
  return `hsl(${hue}, 60%, 42%)`;
}

export default function StockLogo({ symbol, domain, size = 36, className = "" }) {
  const [stage, setStage] = useState(0); // 0: Parqet, 1: unavatar, 2: initials badge
  const sym = (symbol || "").toUpperCase();

  if (stage >= 2 || !sym) {
    return (
      <div
        className={`rounded-full flex items-center justify-center text-white font-extrabold shrink-0 ${className}`}
        style={{ width: size, height: size, background: colorFromSymbol(sym || "?"), fontSize: size * 0.32 }}
      >
        {sym.slice(0, 4) || "?"}
      </div>
    );
  }

  const src =
    stage === 0
      ? `https://assets.parqet.com/logos/symbol/${sym}?format=png`
      : `https://unavatar.io/${domain || `${sym.toLowerCase()}.com`}?size=128`;

  return (
    <img
      src={src}
      alt={sym}
      width={size}
      height={size}
      className={`rounded-full object-contain border border-white/10 bg-white p-[3px] shrink-0 ${className}`}
      style={{ width: size, height: size }}
      onError={() => setStage((s) => s + 1)}
      onLoad={(e) => {
        // A real photo/logo will report its native pixel size. Tiny favicons
        // (16x16, 32x32) stretched up to our display size look pixelated —
        // treat those as a miss and fall through to the next source instead.
        const w = e.target.naturalWidth;
        if (w && w < MIN_ACCEPTABLE_PX) {
          setStage((s) => s + 1);
        }
      }}
    />
  );
}
